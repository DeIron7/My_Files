$(document).ready(function() {
    $('li.drop_child .con_link  .arr_interaction .open_dropdown').on('click' , function() {
        $(this).parent().parent().parent().siblings().find('.dropdown').stop(true ,  false , true).slideUp(500);
        $(this).parent().parent().parent().children('.dropdown').stop(true ,  false , true).slideToggle(500);
    });


    $('.bar_open').on('click' , function() {
        $('.left_bar_navigation').toggleClass('go_out');
        console.log($('.left_bar_navigation').width());
        $('.right_content_bar').toggleClass('old_width');
        $('.right_content_bar').toggleClass('fix_width');
    });

});




